माझी डेअरी - Cow Photo Version

नवीन सुविधा:
- प्रत्येक गाय/जनावरासाठी फोटो upload करता येतो.
- JPG, PNG इ. image files स्वीकारले जातात.
- फोटोची कमाल size 2 MB.
- फोटो त्या जनावराच्या record सोबत browser मध्ये सेव्ह होतो.
- जनावरांच्या table मध्ये फोटो दिसतो.
- नवीन photo न दिल्यास existing photo कायम राहतो.

वापर:
1. index.html Chrome मध्ये उघडा.
2. जनावरे > गायची माहिती भरा.
3. "🐄 गायचा फोटो" मधून फोटो निवडा.
4. "जनावर सेव्ह करा" दाबा.

टीप: हा local prototype आहे. फोटो browser localStorage मध्ये राहतो; browser data clear केल्यास फोटोही हटू शकतो.
